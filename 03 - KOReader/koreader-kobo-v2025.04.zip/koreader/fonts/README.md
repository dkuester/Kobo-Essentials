# koreader-fonts
Fonts for use in KOReader

See individual folders for licenses.
